# AgentQAKit failure reproduction

Test case: `wrong-answer`  
Trial: `8a5a23c2-4d67-4d7c-bc65-384b4d8e205c`  

## Failure summary

Target status: ERROR; violation types: PYTHON_PROTOCOL_ERROR, target_status, missing_output_field.

## Original command

```text
AgentQAKit Web campaign 4c10360f-8b41-4b50-94ca-2a15869fc154
```

## Replay command

```text
agentqa replay failure-8a5a23c2-4d67-4d7c-bc65-384b4d8e205c.zip
```

## Expected behavior

The target and every configured evaluator should pass.

## Actual behavior

Target status: ERROR; violation types: PYTHON_PROTOCOL_ERROR, target_status, missing_output_field.

## Sensitive information

Specifications, interaction arguments, results, errors, and environment data
were normalized and redacted before this bundle and its checksums were created.
Strict replay does not access live dependencies unless explicitly allowed.
