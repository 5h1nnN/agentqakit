# AgentQAKit failure reproduction

Test case: `composite-no-conflict`  
Trial: `f3a53c2b-cb6a-43cb-beb6-c3e51c62144c`  

## Failure summary

Target status: OK; violation types: tool_order.

## Original command

```text
agentqa test run 'D:\1_Document\02_Project\AiC_2026\agentqakit\examples\showcase\campus_ops_agent\agentqa\golden-tests' --target 'D:\1_Document\02_Project\AiC_2026\agentqakit\examples\showcase\campus_ops_agent\agentqa\targets\fixed.yaml' --manifest 'D:\1_Document\02_Project\AiC_2026\agentqakit\examples\showcase\campus_ops_agent\agentqa\manifest-v2.yaml' --artifacts 'D:\1_Document\02_Project\AiC_2026\agentqakit\demo-artifacts\cli-fixed' --seed 0 --concurrency 1 --otlp-port 4318 --trace-flush-timeout 0.25 --replay-mode record --no-trace-receiver
```

## Replay command

```text
agentqa replay failure-f3a53c2b-cb6a-43cb-beb6-c3e51c62144c.zip
```

## Expected behavior

The target and every configured evaluator should pass.

## Actual behavior

Target status: OK; violation types: tool_order.

## Sensitive information

Specifications, interaction arguments, results, errors, and environment data
were normalized and redacted before this bundle and its checksums were created.
Strict replay does not access live dependencies unless explicitly allowed.
